import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.*; 
import ddf.minim.analysis.*; 
import ddf.minim.effects.*; 
import ddf.minim.signals.*; 
import ddf.minim.spi.*; 
import ddf.minim.ugens.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Drawing_and_Music_Program extends PApplet {

 
//Global Variables
//
public void setup() {
   //displayWidth, displayHeight
  population();
  musicSetup();
  textSetup();
  GUISetup();
}//End setup
//
public void draw() {
  populationDraw();
  musicDraw();
  drawingTools();
  GUIDraw();
  textDraw();
}//End draw
//
public void keyPressed() {
  musicKeyPressed();
}//End keyPressed
//
public void mousePressed() {
musicMousePressed();
buttonFunctions();
}//End mousePressed
//
public void mouseReleased(){
drawTool=false;
volumeHeld=false;
}
//End MAIN
//Global Variables
//
public void buttonFunctions() {
//Exit
if(mouseX>=quitButtonX && mouseX<=quitButtonX + quitButtonWidth && mouseY>=quitButtonY && mouseY<=quitButtonY+quitButtonHeight) exit();
//
//Background Tool Colors
if (mouseX>=displayWidth*1/35 && mouseX<=displayWidth*1/35+fillButton && mouseY>= displayWidth*6/35 && mouseY<=displayWidth*6/35+fillButton) {
  splash.play();
  splash.rewind();
  backgroundColour=red;
  GUISetup();
}
//
if (mouseX>=displayWidth*2/35 && mouseX<=displayWidth*2/35+fillButton && mouseY>= displayWidth*6/35 && mouseY<=displayWidth*6/35+fillButton) {
  splash.play();
  splash.rewind();
  backgroundColour=rorange;
  GUISetup();
}
//
if (mouseX>=displayWidth*3/35 && mouseX<=displayWidth*3/35+fillButton && mouseY>= displayWidth*6/35 && mouseY<=displayWidth*6/35+fillButton) {
  splash.play();
  splash.rewind();
  backgroundColour=orange; 
  GUISetup();
}
//
if (mouseX>=displayWidth*4/35 && mouseX<=displayWidth*4/35+fillButton && mouseY>= displayWidth*6/35 && mouseY<=displayWidth*6/35+fillButton) {
  splash.play();
  splash.rewind();
  backgroundColour=yorange;
  GUISetup();
}
//
if (mouseX>=displayWidth*1/35 && mouseX<=displayWidth*1/35+fillButton && mouseY>= displayWidth*7/35 && mouseY<=displayWidth*7/35+fillButton) {
  splash.play();
  splash.rewind();
  backgroundColour=yellow;
  GUISetup();
}
//
if (mouseX>=displayWidth*2/35 && mouseX<=displayWidth*2/35+fillButton && mouseY>= displayWidth*7/35 && mouseY<=displayWidth*7/35+fillButton) {
  splash.play();
  splash.rewind();
  backgroundColour=ygreen;
  GUISetup();
}
//
if (mouseX>=displayWidth*3/35 && mouseX<=displayWidth*3/35+fillButton && mouseY>= displayWidth*7/35 && mouseY<=displayWidth*7/35+fillButton) {
  splash.play();
  splash.rewind();
  backgroundColour=green;
  GUISetup();
}
//
if (mouseX>=displayWidth*4/35 && mouseX<=displayWidth*4/35+fillButton && mouseY>= displayWidth*7/35 && mouseY<=displayWidth*7/35+fillButton) {
  splash.play();
  splash.rewind();
  backgroundColour=bgreen;
  GUISetup();
}
//
if (mouseX>=displayWidth*1/35 && mouseX<=displayWidth*1/35+fillButton && mouseY>= displayWidth*8/35 && mouseY<=displayWidth*8/35+fillButton) {
  splash.play();
  splash.rewind();
  backgroundColour=blue;
  GUISetup();
}
//
if (mouseX>=displayWidth*2/35 && mouseX<=displayWidth*2/35+fillButton && mouseY>= displayWidth*8/35 && mouseY<=displayWidth*8/35+fillButton) {
  splash.play();
  splash.rewind();
  backgroundColour=bviolet;
  GUISetup();
}
//
if (mouseX>=displayWidth*3/35 && mouseX<=displayWidth*3/35+fillButton && mouseY>= displayWidth*8/35 && mouseY<=displayWidth*8/35+fillButton) {
  splash.play();
  splash.rewind();
  backgroundColour=violet;
  GUISetup();
}
//
if (mouseX>=displayWidth*4/35 && mouseX<=displayWidth*4/35+fillButton && mouseY>= displayWidth*8/35 && mouseY<=displayWidth*8/35+fillButton) {
  splash.play();
  splash.rewind();
  backgroundColour=rviolet;
  GUISetup();
}
//
if (mouseX>=displayWidth*1/35 && mouseX<=displayWidth*1/35+fillButton && mouseY>= displayWidth*9/35 && mouseY<=displayWidth*9/35+fillButton) {
  splash.play();
  splash.rewind();
  backgroundColour=black;
  GUISetup();
}
//
if (mouseX>=displayWidth*2/35 && mouseX<=displayWidth*2/35+fillButton && mouseY>= displayWidth*9/35 && mouseY<=displayWidth*9/35+fillButton) {
  splash.play();
  splash.rewind();
  backgroundColour=dgrey;
  GUISetup();
}
//
if (mouseX>=displayWidth*3/35 && mouseX<=displayWidth*3/35+fillButton && mouseY>= displayWidth*9/35 && mouseY<=displayWidth*9/35+fillButton) {
  splash.play();
  splash.rewind();
  backgroundColour=white;
  GUISetup();
}
//
if (mouseX>=displayWidth*4/35 && mouseX<=displayWidth*4/35+fillButton && mouseY>= displayWidth*9/35 && mouseY<=displayWidth*9/35+fillButton) {
  crumple.play();
  crumple.rewind();
  GUISetup();
}
//

//Drawing Tool Colors
if (mouseX>=displayWidth*1/35 && mouseX<=displayWidth*1/35+fillButton && mouseY>= displayWidth*1/35 && mouseY<=displayWidth*1/35+fillButton) {
  scribble.play();
  scribble.rewind();
  toolColour=red;
  eraser=false;
}
//
if (mouseX>=displayWidth*2/35 && mouseX<=displayWidth*2/35+fillButton && mouseY>= displayWidth*1/35 && mouseY<=displayWidth*1/35+fillButton) {
  scribble.play();
  scribble.rewind();
  toolColour=rorange;
  eraser=false;
}
//
if (mouseX>=displayWidth*3/35 && mouseX<=displayWidth*3/35+fillButton && mouseY>= displayWidth*1/35 && mouseY<=displayWidth*1/35+fillButton) {
  scribble.play();
  scribble.rewind();
  toolColour=orange; 
  eraser=false;
}
//
if (mouseX>=displayWidth*4/35 && mouseX<=displayWidth*4/35+fillButton && mouseY>= displayWidth*1/35 && mouseY<=displayWidth*1/35+fillButton) {
  scribble.play();
  scribble.rewind();
  toolColour=yorange;
  eraser=false;
}
//
if (mouseX>=displayWidth*1/35 && mouseX<=displayWidth*1/35+fillButton && mouseY>= displayWidth*2/35 && mouseY<=displayWidth*2/35+fillButton) {
  scribble.play();
  scribble.rewind();
  toolColour=yellow;
  eraser=false;
}
//
if (mouseX>=displayWidth*2/35 && mouseX<=displayWidth*2/35+fillButton && mouseY>= displayWidth*2/35 && mouseY<=displayWidth*2/35+fillButton) {
  scribble.play();
  scribble.rewind();
  toolColour=ygreen;
  eraser=false;
}
//
if (mouseX>=displayWidth*3/35 && mouseX<=displayWidth*3/35+fillButton && mouseY>= displayWidth*2/35 && mouseY<=displayWidth*2/35+fillButton) {
  scribble.play();
  scribble.rewind();
  toolColour=green;
  eraser=false;
}
//
if (mouseX>=displayWidth*4/35 && mouseX<=displayWidth*4/35+fillButton && mouseY>= displayWidth*2/35 && mouseY<=displayWidth*2/35+fillButton) {
  scribble.play();
  scribble.rewind();
  toolColour=bgreen;
  eraser=false;
}
//
if (mouseX>=displayWidth*1/35 && mouseX<=displayWidth*1/35+fillButton && mouseY>= displayWidth*3/35 && mouseY<=displayWidth*3/35+fillButton) {
  scribble.play();
  scribble.rewind();
  toolColour=blue;
  eraser=false;
}
//
if (mouseX>=displayWidth*2/35 && mouseX<=displayWidth*2/35+fillButton && mouseY>= displayWidth*3/35 && mouseY<=displayWidth*3/35+fillButton) {
  scribble.play();
  scribble.rewind();
  toolColour=bviolet;
  eraser=false;
}
//
if (mouseX>=displayWidth*3/35 && mouseX<=displayWidth*3/35+fillButton && mouseY>= displayWidth*3/35 && mouseY<=displayWidth*3/35+fillButton) {
  scribble.play();
  scribble.rewind();
  toolColour=violet;
  eraser=false;
}
//
if (mouseX>=displayWidth*4/35 && mouseX<=displayWidth*4/35+fillButton && mouseY>= displayWidth*3/35 && mouseY<=displayWidth*3/35+fillButton) {
  scribble.play();
  scribble.rewind();
  toolColour=rviolet;
  eraser=false;
}
//
if (mouseX>=displayWidth*1/35 && mouseX<=displayWidth*1/35+fillButton && mouseY>= displayWidth*4/35 && mouseY<=displayWidth*4/35+fillButton) {
  scribble.play();
  scribble.rewind();
  toolColour=black;
  eraser=false;
}
//
if (mouseX>=displayWidth*2/35 && mouseX<=displayWidth*2/35+fillButton && mouseY>= displayWidth*4/35 && mouseY<=displayWidth*4/35+fillButton) {
  scribble.play();
  scribble.rewind();
  toolColour=dgrey;
  eraser=false;
}
//
if (mouseX>=displayWidth*3/35 && mouseX<=displayWidth*3/35+fillButton && mouseY>= displayWidth*4/35 && mouseY<=displayWidth*4/35+fillButton) {
  scribble.play();
  scribble.rewind();
  toolColour=white;
  eraser=false;
}
//
if (mouseX>=displayWidth*4/35 && mouseX<=displayWidth*4/35+fillButton && mouseY>= displayWidth*4/35 && mouseY<=displayWidth*4/35+fillButton) {
  erase.play();
  erase.rewind();
  eraser=true;
}
//
if(eraser==true)toolColour=backgroundColour;
//
//Line draw
if (mouseX>=drawingSurfaceX && mouseX<=drawingSurfaceX+drawingSurfaceWidth && mouseY>=drawingSurfaceY && mouseY<=drawingSurfaceY+drawingSurfaceHeight){
    if (drawTool == false) {
    drawTool = true;
  } else {
    drawTool = false;}}
//Button Paper (Drawing Surface)
    //Stroke Buttons
if (mouseX>=displayWidth*1/35 && mouseX<=displayWidth*1/35+strokeWidth && mouseY>=displayWidth*11/35 && mouseY<=displayWidth*11/35+strokeHeight){
  lineStroke=2;
  select.play();
  select.rewind();
}
//
if (mouseX>=displayWidth*2/35 && mouseX<=displayWidth*2/35+strokeWidth && mouseY>=displayWidth*11/35 && mouseY<=displayWidth*11/35+strokeHeight){
  lineStroke=6;
  select.play();
  select.rewind();
}
//
if (mouseX>=displayWidth*3/35 && mouseX<=displayWidth*3/35+strokeWidth && mouseY>=displayWidth*11/35 && mouseY<=displayWidth*11/35+strokeHeight){
  lineStroke=10;
  select.play();
  select.rewind();
}
//
if (mouseX>=displayWidth*4/35 && mouseX<=displayWidth*4/35+strokeWidth && mouseY>=displayWidth*11/35 && mouseY<=displayWidth*11/35+strokeHeight){
lineStroke=14;
  select.play();
  select.rewind();
}
//Shape Buttons
if (mouseX>=displayWidth*1/35 && mouseX<=displayWidth*1/35+strokeWidth && mouseY>=displayWidth*514/1295 && mouseY<=displayWidth*514/1295+strokeHeight){
  drawLine=true;
  drawCircle=false;
  drawTriangle=false;
  drawRectangle=false;
  select.play();
  select.rewind();
}
if (mouseX>=displayWidth*2/35 && mouseX<=displayWidth*2/35+strokeWidth && mouseY>=displayWidth*514/1295 && mouseY<=displayWidth*514/1295+strokeHeight){
  drawLine=false;
  drawCircle=true;
  drawTriangle=false;
  drawRectangle=false;
  select.play();
  select.rewind();
}
if (mouseX>=displayWidth*3/35 && mouseX<=displayWidth*3/35+strokeWidth && mouseY>=displayWidth*514/1295 && mouseY<=displayWidth*514/1295+strokeHeight){
  drawLine=false;
  drawCircle=false;
  drawTriangle=true;
  drawRectangle=false;
  select.play();
  select.rewind();
}
if (mouseX>=displayWidth*4/35 && mouseX<=displayWidth*4/35+strokeWidth && mouseY>=displayWidth*514/1295 && mouseY<=displayWidth*514/1295+strokeHeight){
  drawLine=false;
  drawCircle=false;
  drawTriangle=false;
  drawRectangle=true;
  select.play();
  select.rewind();
}
}//End buttonFunctions
//Global Variables
float fillButton, strokeWidth, strokeHeight, shapeWidth, shapeHeight;
PImage play, pause, next, back, loop;
//
public void GUIDraw() {

//Background
fill(GUI);
strokeWeight(noStroke);
stroke(GUI);
rect(0, 0, displayWidth*6/35, displayHeight);
rect(0, displayHeight*6/7, displayWidth, displayHeight*1/5);
stroke(strokeReset);
fill(resetColour);
//
//Quit Button
if (mouseX>=quitButtonX && mouseX<=quitButtonX + quitButtonWidth && mouseY>=quitButtonY && mouseY<=quitButtonY+quitButtonHeight) {
quitButtonColour = red;
} else {
quitButtonColour = black;
}//End Quit Button Hoverover
fill(quitButtonColour);
strokeWeight(noStroke);
rect(quitButtonX,quitButtonY, quitButtonWidth, quitButtonHeight);
stroke(reset);
fill(resetColour);
//
//Reset Button
fill(white);
rect(secondTextX, secondTextY, secondTextWidth, secondTextHeight);
fill(black); //Ink
//Draw colour buttons
strokeWeight(noStroke);
//row 1
if(mouseX>=displayWidth*1/35 && mouseX<=displayWidth*1/35+strokeWidth && mouseY>= displayWidth*1/35 && mouseY<=displayWidth*1/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(red);
rect(displayWidth*1/35, displayWidth*1/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*2/35 && mouseX<=displayWidth*2/35+strokeWidth && mouseY>= displayWidth*1/35 && mouseY<=displayWidth*1/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(rorange);
rect(displayWidth*2/35, displayWidth*1/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*3/35 && mouseX<=displayWidth*3/35+strokeWidth && mouseY>= displayWidth*1/35 && mouseY<=displayWidth*1/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(orange);
rect(displayWidth*3/35, displayWidth*1/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*4/35 && mouseX<=displayWidth*4/35+strokeWidth && mouseY>= displayWidth*1/35 && mouseY<=displayWidth*1/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(yorange);
rect(displayWidth*4/35, displayWidth*1/35, strokeWidth, strokeWidth);
strokeWeight(0);
//row 2
if(mouseX>=displayWidth*1/35 && mouseX<=displayWidth*1/35+strokeWidth && mouseY>= displayWidth*2/35 && mouseY<=displayWidth*2/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(yellow);
rect(displayWidth*1/35, displayWidth*2/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*2/35 && mouseX<=displayWidth*2/35+strokeWidth && mouseY>= displayWidth*2/35 && mouseY<=displayWidth*2/35+strokeWidth) {strokeWeight(2);} else {
 strokeWeight(0);}
fill(ygreen);
rect(displayWidth*2/35, displayWidth*2/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*3/35 && mouseX<=displayWidth*3/35+strokeWidth && mouseY>= displayWidth*2/35 && mouseY<=displayWidth*2/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(green);
rect(displayWidth*3/35, displayWidth*2/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*4/35 && mouseX<=displayWidth*4/35+strokeWidth && mouseY>= displayWidth*2/35 && mouseY<=displayWidth*2/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(bgreen);
rect(displayWidth*4/35, displayWidth*2/35, strokeWidth, strokeWidth);
strokeWeight(0);
//row 3
if(mouseX>=displayWidth*1/35 && mouseX<=displayWidth*1/35+strokeWidth && mouseY>= displayWidth*3/35 && mouseY<=displayWidth*3/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(blue);
rect(displayWidth*1/35, displayWidth*3/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*2/35 && mouseX<=displayWidth*2/35+strokeWidth && mouseY>= displayWidth*3/35 && mouseY<=displayWidth*3/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(bviolet);
rect(displayWidth*2/35, displayWidth*3/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*3/35 && mouseX<=displayWidth*3/35+strokeWidth && mouseY>= displayWidth*3/35 && mouseY<=displayWidth*3/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(violet);
rect(displayWidth*3/35, displayWidth*3/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*4/35 && mouseX<=displayWidth*4/35+strokeWidth && mouseY>= displayWidth*3/35 && mouseY<=displayWidth*3/35+strokeWidth) {strokeWeight(2);} else {
strokeWeight(0);}
fill(rviolet);
rect(displayWidth*4/35, displayWidth*3/35, strokeWidth, strokeWidth);
strokeWeight(0);
//row 4
if(mouseX>=displayWidth*1/35 && mouseX<=displayWidth*1/35+strokeWidth && mouseY>= displayWidth*4/35 && mouseY<=displayWidth*4/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(black);
rect(displayWidth*1/35, displayWidth*4/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*2/35 && mouseX<=displayWidth*2/35+strokeWidth && mouseY>= displayWidth*4/35 && mouseY<=displayWidth*4/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(dgrey);
rect(displayWidth*2/35, displayWidth*4/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*3/35 && mouseX<=displayWidth*3/35+strokeWidth && mouseY>= displayWidth*4/35 && mouseY<=displayWidth*4/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(white);
rect(displayWidth*3/35, displayWidth*4/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*4/35 && mouseX<=displayWidth*4/35+strokeWidth && mouseY>= displayWidth*4/35 && mouseY<=displayWidth*4/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(backgroundColour);
rect(displayWidth*4/35, displayWidth*4/35, strokeWidth, strokeWidth);
strokeWeight(0);
//
strokeWeight(strokeReset);
//background fill buttons
strokeWeight(noStroke);
//row 1
if(mouseX>=displayWidth*1/35 && mouseX<=displayWidth*1/35+strokeWidth && mouseY>= displayWidth*6/35 && mouseY<=displayWidth*6/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(red);
rect(displayWidth*1/35, displayWidth*6/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*2/35 && mouseX<=displayWidth*2/35+strokeWidth && mouseY>= displayWidth*6/35 && mouseY<=displayWidth*6/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(rorange);
rect(displayWidth*2/35, displayWidth*6/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*3/35 && mouseX<=displayWidth*3/35+strokeWidth && mouseY>= displayWidth*6/35 && mouseY<=displayWidth*6/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(orange);
rect(displayWidth*3/35, displayWidth*6/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*4/35 && mouseX<=displayWidth*4/35+strokeWidth && mouseY>= displayWidth*6/35 && mouseY<=displayWidth*6/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(yorange);
rect(displayWidth*4/35, displayWidth*6/35, strokeWidth, strokeWidth);
strokeWeight(0);
//row 2
if(mouseX>=displayWidth*1/35 && mouseX<=displayWidth*1/35+strokeWidth && mouseY>= displayWidth*7/35 && mouseY<=displayWidth*7/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(yellow);
rect(displayWidth*1/35, displayWidth*7/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*2/35 && mouseX<=displayWidth*2/35+strokeWidth && mouseY>= displayWidth*7/35 && mouseY<=displayWidth*7/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(ygreen);
rect(displayWidth*2/35, displayWidth*7/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*3/35 && mouseX<=displayWidth*3/35+strokeWidth && mouseY>= displayWidth*7/35 && mouseY<=displayWidth*7/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(green);
rect(displayWidth*3/35, displayWidth*7/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*4/35 && mouseX<=displayWidth*4/35+strokeWidth && mouseY>= displayWidth*7/35 && mouseY<=displayWidth*7/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(bgreen);
rect(displayWidth*4/35, displayWidth*7/35, strokeWidth, strokeWidth);
strokeWeight(0);
//row 3
if(mouseX>=displayWidth*1/35 && mouseX<=displayWidth*1/35+strokeWidth && mouseY>= displayWidth*8/35 && mouseY<=displayWidth*8/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(blue);
rect(displayWidth*1/35, displayWidth*8/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*2/35 && mouseX<=displayWidth*2/35+strokeWidth && mouseY>= displayWidth*8/35 && mouseY<=displayWidth*8/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(bviolet);
rect(displayWidth*2/35, displayWidth*8/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*3/35 && mouseX<=displayWidth*3/35+strokeWidth && mouseY>= displayWidth*8/35 && mouseY<=displayWidth*8/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(violet);
rect(displayWidth*3/35, displayWidth*8/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*4/35 && mouseX<=displayWidth*4/35+strokeWidth && mouseY>= displayWidth*8/35 && mouseY<=displayWidth*8/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(rviolet);
rect(displayWidth*4/35, displayWidth*8/35, strokeWidth, strokeWidth);
strokeWeight(0);
//row 4
if(mouseX>=displayWidth*1/35 && mouseX<=displayWidth*1/35+strokeWidth && mouseY>= displayWidth*9/35 && mouseY<=displayWidth*9/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(black);
rect(displayWidth*1/35, displayWidth*9/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*2/35 && mouseX<=displayWidth*2/35+strokeWidth && mouseY>= displayWidth*9/35 && mouseY<=displayWidth*9/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(dgrey);
rect(displayWidth*2/35, displayWidth*9/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*3/35 && mouseX<=displayWidth*3/35+strokeWidth && mouseY>= displayWidth*9/35 && mouseY<=displayWidth*9/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(white);
rect(displayWidth*3/35, displayWidth*9/35, strokeWidth, strokeWidth);
strokeWeight(0);
if(mouseX>=displayWidth*4/35 && mouseX<=displayWidth*4/35+strokeWidth && mouseY>= displayWidth*9/35 && mouseY<=displayWidth*9/35+strokeWidth) {strokeWeight(2);} else {
  strokeWeight(0);}
fill(backgroundColour);
rect(displayWidth*4/35, displayWidth*9/35, strokeWidth, strokeWidth);
strokeWeight(0);
//
//Stroke buttons
if (mouseX>=displayWidth*1/35 && mouseX<=displayWidth*1/35+strokeWidth && mouseY>=displayWidth*11/35 && mouseY<=displayWidth*11/35+strokeHeight){ 
  strokeWeight(2);
  fill(yellow);
  stroke(black);
  rect(displayWidth*1/35, displayWidth*11/35, strokeWidth, strokeHeight);
  stroke(toolColour);
  line(displayWidth*1/35+(strokeWidth*1/2), displayWidth*11/35+(strokeHeight*1/8), displayWidth*1/35+(strokeWidth*1/2), displayWidth*11/35+(strokeHeight*7/8));
} else {
  strokeWeight(0);
  fill(white);
  stroke(black);
  rect(displayWidth*1/35, displayWidth*11/35, strokeWidth, strokeHeight);
  strokeWeight(2);
  stroke(toolColour);
  line(displayWidth*1/35+(strokeWidth*1/2), displayWidth*11/35+(strokeHeight*1/8), displayWidth*1/35+(strokeWidth*1/2), displayWidth*11/35+(strokeHeight*7/8));
}
if (mouseX>=displayWidth*2/35 && mouseX<=displayWidth*2/35+strokeWidth && mouseY>=displayWidth*11/35 && mouseY<=displayWidth*11/35+strokeHeight){ 
  strokeWeight(2);
  fill(yellow);
  stroke(black);
  rect(displayWidth*2/35, displayWidth*11/35, strokeWidth, strokeHeight);
  stroke(toolColour);
  strokeWeight(6);
  line(displayWidth*2/35+(strokeWidth*1/2), displayWidth*11/35+(strokeHeight*1/8), displayWidth*2/35+(strokeWidth*1/2), displayWidth*11/35+(strokeHeight*7/8));
} else {
  strokeWeight(0);
  fill(white);
  stroke(black);
  rect(displayWidth*2/35, displayWidth*11/35, strokeWidth, strokeHeight);
  stroke(toolColour);
  strokeWeight(6);
  line(displayWidth*2/35+(strokeWidth*1/2), displayWidth*11/35+(strokeHeight*1/8), displayWidth*2/35+(strokeWidth*1/2), displayWidth*11/35+(strokeHeight*7/8));
}
if (mouseX>=displayWidth*3/35 && mouseX<=displayWidth*3/35+strokeWidth && mouseY>=displayWidth*11/35 && mouseY<=displayWidth*11/35+strokeHeight){ 
  strokeWeight(2);
  fill(yellow);
  stroke(black);
  rect(displayWidth*3/35, displayWidth*11/35, strokeWidth, strokeHeight);
  stroke(toolColour);
  strokeWeight(10);
  line(displayWidth*3/35+(strokeWidth*1/2), displayWidth*11/35+(strokeHeight*1/8), displayWidth*3/35+(strokeWidth*1/2), displayWidth*11/35+(strokeHeight*7/8));
} else {
  strokeWeight(0);
  fill(white);
  stroke(black);
  rect(displayWidth*3/35, displayWidth*11/35, strokeWidth, strokeHeight);
  stroke(toolColour);
  strokeWeight(10);
  line(displayWidth*3/35+(strokeWidth*1/2), displayWidth*11/35+(strokeHeight*1/8), displayWidth*3/35+(strokeWidth*1/2), displayWidth*11/35+(strokeHeight*7/8));
}
if (mouseX>=displayWidth*4/35 && mouseX<=displayWidth*4/35+strokeWidth && mouseY>=displayWidth*11/35 && mouseY<=displayWidth*11/35+strokeHeight){ 
  strokeWeight(2);
  fill(yellow);
  stroke(black);
  rect(displayWidth*4/35, displayWidth*11/35, strokeWidth, strokeHeight);
  strokeWeight(14);
  stroke(toolColour);
  line(displayWidth*4/35+(strokeWidth*1/2), displayWidth*11/35+(strokeHeight*1/8), displayWidth*4/35+(strokeWidth*1/2), displayWidth*11/35+(strokeHeight*7/8));
} else {
  strokeWeight(0);
  fill(white);
  stroke(black);
  rect(displayWidth*4/35, displayWidth*11/35, strokeWidth, strokeHeight);
  strokeWeight(14);
  stroke(toolColour);
  line(displayWidth*4/35+(strokeWidth*1/2), displayWidth*11/35+(strokeHeight*1/8), displayWidth*4/35+(strokeWidth*1/2), displayWidth*11/35+(strokeHeight*7/8));
}
stroke(black);
//
//Shape buttons
if (mouseX>=displayWidth*1/35 && mouseX<=displayWidth*1/35+strokeWidth && mouseY>=displayWidth*514/1295 && mouseY<=displayWidth*514/1295+strokeHeight){ 
  stroke(black);
  strokeWeight(2);
  fill(yellow);
  rect(displayWidth*1/35, displayWidth*514/1295, strokeWidth, strokeHeight);
  stroke(toolColour);
  strokeWeight(lineStroke);
  line(displayWidth*1/35+(strokeWidth*1/2), displayWidth*514/1295+(strokeHeight*1/8), displayWidth*1/35+(strokeWidth*1/2), displayWidth*514/1295+(strokeHeight*7/8));
} else {
  stroke(black);
  strokeWeight(0);
  fill(white);
  rect(displayWidth*1/35, displayWidth*514/1295, strokeWidth, strokeHeight);
  stroke(toolColour);
  strokeWeight(lineStroke);
  line(displayWidth*1/35+(strokeWidth*1/2), displayWidth*514/1295+(strokeHeight*1/8), displayWidth*1/35+(strokeWidth*1/2), displayWidth*514/1295+(strokeHeight*7/8));
}
if (mouseX>=displayWidth*2/35 && mouseX<=displayWidth*2/35+strokeWidth && mouseY>=displayWidth*514/1295 && mouseY<=displayWidth*514/1295+strokeHeight){ 
  stroke(black);
  strokeWeight(2);
  fill(yellow);
  rect(displayWidth*2/35, displayWidth*514/1295, strokeWidth, strokeHeight);
  fill(toolColour);
  stroke(toolColour);
  ellipse(displayWidth*2/35+(strokeWidth*1/2), displayWidth*514/1295+strokeHeight*1/2, drawingDiameter, drawingDiameter);
} else {
  stroke(black);
  strokeWeight(0);
  fill(white);
  rect(displayWidth*2/35, displayWidth*514/1295, strokeWidth, strokeHeight);
  fill(toolColour);
  stroke(toolColour);
  ellipse(displayWidth*2/35+(strokeWidth*1/2), displayWidth*514/1295+strokeHeight*1/2, drawingDiameter, drawingDiameter);
}
if (mouseX>=displayWidth*3/35 && mouseX<=displayWidth*3/35+strokeWidth && mouseY>=displayWidth*514/1295 && mouseY<=displayWidth*514/1295+strokeHeight){ 
  stroke(black);
  strokeWeight(2);
  fill(yellow);
  rect(displayWidth*3/35, displayWidth*514/1295, strokeWidth, strokeHeight);
  fill(toolColour);
  stroke(toolColour);
  triangle(displayWidth*3/35+(strokeWidth*1/2), displayWidth*514/1295+strokeHeight*1/4, displayWidth*3/35+(strokeWidth*1/6), displayWidth*514/1295+strokeHeight*3/4, displayWidth*3/35+(strokeWidth*5/6), displayWidth*514/1295+strokeHeight*3/4);
} else {
  stroke(black);
  strokeWeight(0);
  fill(white);
  rect(displayWidth*3/35, displayWidth*514/1295, strokeWidth, strokeHeight);
  fill(toolColour);
  stroke(toolColour);
  triangle(displayWidth*3/35+(strokeWidth*1/2), displayWidth*514/1295+strokeHeight*1/4, displayWidth*3/35+(strokeWidth*1/6), displayWidth*514/1295+strokeHeight*3/4, displayWidth*3/35+(strokeWidth*5/6), displayWidth*514/1295+strokeHeight*3/4);
}
if (mouseX>=displayWidth*4/35 && mouseX<=displayWidth*4/35+strokeWidth && mouseY>=displayWidth*514/1295 && mouseY<=displayWidth*514/1295+strokeHeight){ 
  stroke(black);
  strokeWeight(2);
  fill(yellow);
  rect(displayWidth*4/35, displayWidth*514/1295, strokeWidth, strokeHeight);
  stroke(toolColour);
  fill(toolColour);
  rect(displayWidth*4/35+strokeWidth*1/8, displayWidth*514/1295+strokeHeight*1/8, strokeWidth*6/8, strokeHeight*6/8);
} else {
  stroke(black);
  strokeWeight(0);
  fill(white);
  rect(displayWidth*4/35, displayWidth*514/1295, strokeWidth, strokeHeight);
  stroke(toolColour);
  fill(toolColour);
  rect(displayWidth*4/35+strokeWidth*1/8, displayWidth*514/1295+strokeHeight*1/8, strokeWidth*6/8, strokeHeight*6/8);
  stroke(reset);
}
//
strokeWeight(strokeReset);
fill(white);
//
if (paper==true) GUISetup();
//
//Music Progress Bar
stroke(black);
rect(displayWidth*16/35, displayHeight*27/28, progressBarWidth, progressBarHeight);
fill(black);
rect(displayWidth*16/35, displayHeight*27/28,(PApplet.parseFloat(song[currentSong].position())/PApplet.parseFloat(song[currentSong].length()))*progressBarWidth, progressBarHeight);
fill(white);
ellipse(displayWidth*16/35+(PApplet.parseFloat(song[currentSong].position())/PApplet.parseFloat(song[currentSong].length()))*progressBarWidth, displayHeight*27/28+displayHeight*1/400, displayHeight*1/125,displayHeight*1/125);
//
//Volume Slider
rect(displayWidth*30/35, displayHeight*27/28, displayWidth*4/35, progressBarHeight);
fill(black);
if(volumeButton<=1 && volumeButton>=0)rect(displayWidth*30/35, displayHeight*27/28, (volumeButton*displayWidth*4/35), progressBarHeight);
if(volumeButton>=1 )rect(displayWidth*30/35, displayHeight*27/28, (displayWidth*4/35), progressBarHeight);
fill(white);
//
//Music Buttons
if(mouseX>=displayWidth*54/105 && mouseX<=displayWidth*54/105+fillButton && mouseY>=displayHeight*50/56 && mouseY<=displayHeight*50/56+fillButton){
  fill(yellow);
  strokeWeight(2);
  rect(displayWidth*54/105, displayHeight*50/56, fillButton, fillButton);
}else{
  if(loopF==true){
    fill(yellow);
  }else{
  fill(white);
  }
  strokeWeight(noStroke);
  rect(displayWidth*54/105, displayHeight*50/56, fillButton, fillButton);
}
if(mouseX>=displayWidth*58/105 && mouseX<=displayWidth*58/105+fillButton && mouseY>=displayHeight*50/56 && mouseY<=displayHeight*50/56+fillButton){
  fill(yellow);
  strokeWeight(2);
  rect(displayWidth*58/105, displayHeight*50/56, fillButton, fillButton);
}else{
  fill(white);
  strokeWeight(noStroke);
  rect(displayWidth*58/105, displayHeight*50/56, fillButton, fillButton);
}
if(mouseX>=displayWidth*66/105 && mouseX<=displayWidth*66/105+fillButton && mouseY>=displayHeight*50/56 && mouseY<=displayHeight*50/56+fillButton){
  fill(yellow);
  strokeWeight(2);
  rect(displayWidth*66/105, displayHeight*50/56, fillButton, fillButton);
}else{
  fill(white);
  strokeWeight(noStroke);
  rect(displayWidth*66/105, displayHeight*50/56, fillButton, fillButton);
}
if(mouseX>=displayWidth*62/105 && mouseX<=displayWidth*62/105+fillButton && mouseY>=displayHeight*50/56 && mouseY<=displayHeight*50/56+fillButton){
  fill(yellow);
  strokeWeight(2);
  rect(displayWidth*62/105, displayHeight*50/56, fillButton, fillButton);
}else{
  fill(white);
  strokeWeight(noStroke);
  rect(displayWidth*62/105, displayHeight*50/56, fillButton, fillButton);
}
strokeWeight(2);
fill(white);
rect(displayWidth*7/35,displayHeight*49/56, displayWidth*6/35, displayHeight*3/35);
//
if(song[currentSong].isPlaying()) image(pause, displayWidth*62/105, displayHeight*50/56, fillButton, fillButton);
//
if(!song[currentSong].isPlaying()) image(play, displayWidth*62/105, displayHeight*50/56, fillButton, fillButton);
//
image(next, displayWidth*66/105, displayHeight*50/56, fillButton, fillButton);
//
image(back, displayWidth*58/105, displayHeight*50/56, fillButton, fillButton);
//
image(loop, displayWidth*54/105, displayHeight*50/56, fillButton, fillButton);

}//End GUIDraw
//
//Global Variables
//
public void GUISetup() {
  fill(backgroundColour);
  stroke(backgroundColour);
  noStroke();
  rect(drawingSurfaceX, drawingSurfaceY, drawingSurfaceWidth, drawingSurfaceHeight);
  stroke(1); 
  paper=false;
  fill(reset);
  pause = loadImage("images/pause.png");
  play = loadImage("images/playicon.png");
  next = loadImage("images/next.png");
  back = loadImage("images/rewind.png");
  loop = loadImage("images/loop.png");
}//End GUISetup
//






//Global Variables
Minim minim; 
Boolean pauseTrue=false, stopTrue = false;
int numberOfSongs=5;
int trueNumberOfSongs=numberOfSongs-1;
AudioPlayer[] song = new AudioPlayer[numberOfSongs];
AudioPlayer splash;
AudioPlayer scribble;
AudioPlayer crumple;
AudioPlayer erase;
AudioPlayer click;
AudioPlayer select;
AudioMetaData[] songMetaData = new AudioMetaData[numberOfSongs]; 
int currentSong = numberOfSongs - numberOfSongs;
public void musicSetup () {
   minim = new Minim(this);
  song[currentSong] = minim.loadFile("musicFolder/SomebodyThatIUsedToKnow.mp3");
  song[currentSong+=1] = minim.loadFile("musicFolder/Without Me.mp3");
  song[currentSong+=1] = minim.loadFile("musicFolder/Jetpack Joyride Theme.mp3");
  song[currentSong+=1] = minim.loadFile("musicFolder/[Electro] - Laszlo - Supernova [Monstercat Release].mp3");
  song[currentSong+=1] = minim.loadFile("musicFolder/Megalovania BASS BOOSTED.mp3");
  splash = minim.loadFile("soundEffects/Muddy-Water-Splash-www.fesliyanstudios.com.mp3");
  scribble = minim.loadFile("soundEffects/68885__aboe__scribsht4.wav");
  crumple = minim.loadFile("soundEffects/Crumbling-Paper-3-www.fesliyanstudios.com.mp3");
  erase = minim.loadFile("soundEffects/586466__ldf99__pen-erasing.wav");
  click = minim.loadFile("soundEffects/click.mp3");
  select = minim.loadFile("soundEffects/select.wav");
  //
  currentSong-=currentSong; 
  for (int i=currentSong; i<song.length; i++) {
  songMetaData[i] = song[i].getMetaData();
  }
  //
}//End musicSetup
//
public void musicDraw () {
  if (song[currentSong].isLooping()) println("There are", song[currentSong].loopCount(), "loops left");
  if (song[currentSong].isPlaying() && !song[currentSong].isLooping()) println("Play Once");
  if (song[currentSong].isPlaying()) println("Time elapsed", song[currentSong].position()/1000, "Song Length", song[currentSong].length()/1000 ); //value in milliseconds
  if (!song[currentSong].isPlaying()) {
  if(!song[currentSong].isPlaying() && currentSong<trueNumberOfSongs && pauseTrue == false && stopTrue == false && loopF==false) {
  song[currentSong].rewind();
  currentSong+=1;
  song[currentSong].play();
  } else if (currentSong == trueNumberOfSongs && !song[currentSong].isPlaying() && pauseTrue==false && stopTrue == false && loopF==false) {
  song[currentSong].pause();
  song[currentSong].rewind();
  currentSong -= currentSong;
  song[currentSong].play();
  } 
  } 
 //
  if(volumeButton<=0 ){
    song[currentSong].mute();
  }else{
    song[currentSong].unmute();
  }
  println(volumeButton);
}//End musicDraw
//
public void musicKeyPressed () {
  if (key=='1' || key=='2' || key=='3' || key=='4' || key=='5' || key=='6' || key=='7' || key=='8' || key=='9') {//looping functions
  String keystr = String.valueOf(key);
  println("Looping", keystr, "times");
  println("Number of Repeats is", keystr);
  int num = PApplet.parseInt(keystr);
  song[currentSong].loop(num);
  }
  //
  //
  if (key=='l' || key=='L' ) song[currentSong].loop();
  if ( key=='p' || key=='P' ){ 
  if(song[currentSong].isPlaying()){
  song[currentSong].pause();
  pauseTrue=true;
  } else if (song[currentSong].position()>=song[currentSong].length()-song[currentSong].length()*1/10){ 
  
  song[currentSong].rewind();
  song[currentSong].play();
  }else {
  song[currentSong].play();
  pauseTrue=false;
  stopTrue=false;
  }
  }
  //End play-pause button
  //
  //Forward and reverse button
  if (key=='f' || key=='F') song[currentSong].skip(5000); 
  if (key=='r' || key=='R') song[currentSong].skip(-5000); 
  //Mute button
  /*
  if (key=='m' ||key=='M') {
  if(song[currentSong].isMuted() ) {
  song[currentSong].unmute();
  } else {
    song[currentSong].mute();
  }
}
*/
//
  if(key=='s' || key=='S'){
  if(song[currentSong].isPlaying()) {
  song[currentSong].pause();
  song[currentSong].rewind();
  stopTrue=true;
  }else{
  song[currentSong].rewind();
  }
  }//End stop button
  //
  
  if (key=='n'|| key=='N') {
  if(song[currentSong].isPlaying() && currentSong < trueNumberOfSongs) {
  song[currentSong].pause();
  song[currentSong].rewind();
  currentSong++;
  song[currentSong].play();
  } else if (currentSong == trueNumberOfSongs && song[currentSong].isPlaying()) {
  song[currentSong].pause();
  song[currentSong].rewind();
  currentSong -= currentSong;
  song[currentSong].play();
  } else if (currentSong == trueNumberOfSongs && !song[currentSong].isPlaying()) {
  song[currentSong].pause();
  song[currentSong].rewind();
  currentSong -= currentSong;
  }else {
  song[currentSong].pause();
  song[currentSong].rewind();
  currentSong++;
  }
  }
  //
  if (key=='b'|| key=='B' ) {
  if(song[currentSong].isPlaying() && currentSong >=1) {
  song[currentSong].pause();
  song[currentSong].rewind();
  currentSong-=1;
  song[currentSong].play();
  } else if (currentSong == 0 && song[currentSong].isPlaying()) {
  song[currentSong].pause();
  song[currentSong].rewind();
  currentSong+=numberOfSongs-1;
  song[currentSong].play();
  } else if (currentSong == 0 && !song[currentSong].isPlaying()) {
  song[currentSong].pause();
  song[currentSong].rewind();
  currentSong+=numberOfSongs-1;
  }
  else {
  song[currentSong].pause();
  song[currentSong].rewind();
  currentSong-=1;
  }
  }
  
}//End musicKeyPressed
//
public void musicMousePressed () {
  //Progress Bar Function
  if (mouseX>=displayWidth*16/35 && mouseX<=displayWidth*16/35+progressBarWidth && mouseY>=displayHeight*27/28 && mouseY<=displayHeight*27/28+progressBarHeight){ 
    if(song[currentSong].isPlaying()){
    song[currentSong].play(newTime);
    loopF=false;
    }
    if(!song[currentSong].isPlaying()){
    song[currentSong].play(newTime);
    song[currentSong].pause();
    loopF=false;
    }
  }
  //Music Player Buttons
  if(mouseX>=displayWidth*30/35 && mouseX<=displayWidth*34/35 && mouseY>=displayHeight*27/28 && mouseY<=displayHeight*27/28+progressBarHeight) volumeHeld=true;
  //Previous Button
  if(mouseX>=displayWidth*58/105 && mouseX<=displayWidth*58/105+fillButton && mouseY>=displayHeight*50/56 && mouseY<=displayHeight*50/56+fillButton){
  if(song[currentSong].position()<=5000){
  if(song[currentSong].isPlaying() && currentSong >=1) {
  song[currentSong].pause();
  song[currentSong].rewind();
  currentSong-=1;
  song[currentSong].play();
  click.play();
  click.rewind();
  loopF=false;
  } else if (currentSong == 0 && song[currentSong].isPlaying()) {
  song[currentSong].pause();
  song[currentSong].rewind();
  currentSong+=numberOfSongs-1;
  song[currentSong].play();
  click.play();
  click.rewind();
  loopF=false;
  } else if (currentSong == 0 && !song[currentSong].isPlaying()) {
  song[currentSong].pause();
  song[currentSong].rewind();
  currentSong+=numberOfSongs-1;
  click.play();
  click.rewind();
  loopF=false;
  }else {
  song[currentSong].pause();
  song[currentSong].rewind();
  currentSong-=1;
  click.play();
  click.rewind();
  loopF=false;
  }
  }
  if(song[currentSong].position()>=5000){
  if(song[currentSong].isPlaying()){
  song[currentSong].rewind();
  loopF=false;
  }
  if(!song[currentSong].isPlaying()){
  song[currentSong].rewind();
  song[currentSong].pause();
  loopF=false;
  }
  } 
  }
  //
  //Next Button
  if(mouseX>=displayWidth*66/105 && mouseX<=displayWidth*66/105+fillButton && mouseY>=displayHeight*50/56 && mouseY<=displayHeight*50/56+fillButton ){
    if(song[currentSong].isPlaying() && currentSong < trueNumberOfSongs) {
  song[currentSong].pause();
  song[currentSong].rewind();
  currentSong++;
  song[currentSong].play();
  click.play();
  click.rewind();
  loopF=false;
  } else if (currentSong == trueNumberOfSongs && song[currentSong].isPlaying()) {
  song[currentSong].pause();
  song[currentSong].rewind();
  currentSong -= currentSong;
  song[currentSong].play();
  click.play();
  click.rewind();
  loopF=false;
  } else if (currentSong == trueNumberOfSongs && !song[currentSong].isPlaying()) {
  song[currentSong].pause();
  song[currentSong].rewind();
  currentSong -= currentSong;
  click.play();
  click.rewind();
  loopF=false;
  }else {
    loopF=false;
  song[currentSong].pause();
  song[currentSong].rewind();
  currentSong++;
  click.play();
  click.rewind();
  }
  }
  //Loop
if(mouseX>=displayWidth*54/105 && mouseX<=displayWidth*54/105+fillButton && mouseY>=displayHeight*50/56 && mouseY<=displayHeight*50/56+fillButton && loopF==false){
song[currentSong].loop();
click.play();
click.rewind();
loopF=true;
}else if(mouseX>=displayWidth*54/105 && mouseX<=displayWidth*54/105+fillButton && mouseY>=displayHeight*50/56 && mouseY<=displayHeight*50/56+fillButton && loopF==true){
song[currentSong].play();
click.play();
click.rewind();
loopF=false;
}
  //Pause Button
  if(mouseX>=displayWidth*62/105 && mouseX<=displayWidth*62/105+fillButton && mouseY>=displayHeight*50/56 && mouseY<=displayHeight*50/56+fillButton && song[currentSong].isPlaying()){
    song[currentSong].pause();
    pauseTrue=true;
    loopF=false;
    click.play();
    click.rewind();
    }else if(mouseX>=displayWidth*62/105 && mouseX<=displayWidth*62/105+fillButton && mouseY>=displayHeight*50/56 && mouseY<=displayHeight*50/56+fillButton && !song[currentSong].isPlaying()){
    click.play();
    click.rewind();
    song[currentSong].pause();
    song[currentSong].play();
    pauseTrue=false;
    loopF=false;
}
  
}//End musicMousePressed
//Global Variables
Boolean drawTool=false, drawLine = true, eraser=false, paper=false, drawCircle = false, drawTriangle=false, drawRectangle=false, volumeHeld=false, loopF = false;
float drawingSurfaceX, drawingSurfaceY, drawingSurfaceWidth, drawingSurfaceHeight;
float quitButtonX, quitButtonY, quitButtonWidth, quitButtonHeight;
float drawingDiameter;
float secondTextX, secondTextY, secondTextWidth, secondTextHeight;
float progressBarHeight, progressBarWidth, setTime, volume, volumeButton;
int minute1, minute2, seconds1, seconds2, seconds3;
int strokeReset = 2, noStroke = 0, reset = 1, lineStroke, frameRate;
int newTime;
String currentTime, totalTime;
int backgroundColour, toolColour, white = 0xffFFFFFF, lgrey=0xff8B8B83, dgrey=0xff585858, resetColour = white, black = 0, quitButtonColour, GUI = 0xff969EA5, blue=0xff0000FF, red=0xffFF0000, yellow=0xffFFE600, green=0xff2A8917, ygreen=0xff36FF00, bgreen=0xff4DAD94, bviolet=0xff5112C9, violet=0xff8B12C9, rviolet=0xffE012BB, rorange=0xffE03B12, orange=0xffE07D12, yorange=0xffE0AA12;
//
public void population() {
  frameRate = 240;
  volumeButton=0.5f;
  drawingSurfaceX = displayWidth*6/35;
  drawingSurfaceY = displayHeight*0;
  drawingSurfaceWidth = displayWidth*30/35;
  drawingSurfaceHeight = displayHeight*6/7;
  drawingDiameter = displayHeight*1/50;
  quitButtonX = displayWidth*39/40;
  quitButtonY = displayHeight*0;
  quitButtonWidth = displayWidth*1/40; // 2/20=1/10
  quitButtonHeight = displayWidth*1/40;
  secondTextX = displayWidth*4/35;
  secondTextY = displayWidth*9/35;
  secondTextWidth = displayWidth*1/37;
  secondTextHeight = displayWidth*1/37;
  fillButton = displayWidth*1/35;
  strokeWidth = displayWidth*1/37;
  strokeHeight = displayWidth*2/37;
  shapeWidth = displayWidth*1/37;
  shapeHeight = displayWidth*2/37;
  backgroundColour=white;
  toolColour=black;
  lineStroke=2;
  progressBarHeight=displayHeight*1/200;
  progressBarWidth=displayWidth*9/35;
}//End population

public void populationDraw() {
  setTime =  PApplet.parseFloat(mouseX-displayWidth*16/35) / PApplet.parseFloat(displayWidth*9/35);
  newTime = PApplet.parseInt(setTime*song[currentSong].length());
  volume = PApplet.parseFloat(mouseX-displayWidth*33/38);
  if(volumeHeld==true){
    volumeButton = PApplet.parseFloat(mouseX-displayWidth*30/35) / PApplet.parseFloat(displayWidth*4/35); 
    song[currentSong].setGain(volume);
  }
  //
  seconds1=song[currentSong].position()/1000;
  minute1=song[currentSong].position()/1000/60;
  seconds2= seconds1-(minute1*60);
  seconds3=song[currentSong].length()/10000;
  minute2=song[currentSong].length()/1000/60;
  //
  if(seconds2<10){
  currentTime= minute1+":"+"0"+seconds2;
  }else{
  currentTime= minute1+":"+seconds2;
  }
  totalTime= minute2+":"+seconds3;
  //
  frameRate(frameRate);
}//End populationDraw
//Global Variables
PFont font;
int initialFontSize = 55;
int size;
String quitButtonString = "x";
String secondTextString = "Paper";
String erases = "Eraser";
String time1 = "4:04";
String time2 = "4:50";
String time3 = "2:17";
String time4 = "5:45";
String time5 = "5:00";
String pen = "Pen Colours";
String canvas = "Canvas Colours";
String stroke = "Stroke Weight";
String shapes = "Shapes";
//
public void textSetup() {
   font = createFont ("Leelawadee UI Semilight", initialFontSize);
}//End textSetup
//
public void textDraw() {
//Text, Quit Button
fill(white);
textAlign (CENTER, CENTER);
size = 45; //Change until fit
textFont(font, size);
text(quitButtonString, quitButtonX, quitButtonY, quitButtonWidth, quitButtonHeight);
fill(resetColour);
//
//New paper Button
if(backgroundColour==black){
fill(white); 
} else { 
fill(black);
}
textAlign (CENTER, CENTER);
size = 20; //Change until fit
textFont(font, size);
text(secondTextString, secondTextX, secondTextY, secondTextWidth, secondTextHeight);
text(erases, displayWidth*4/35, displayWidth*4/35, strokeWidth, strokeWidth);
fill(resetColour);
//
fill(black);
textAlign(CENTER,CENTER);
if(currentSong==0){
  size=30;
}else{
  size=40;
}
textFont(font, size);
text(songMetaData[currentSong].title(), displayWidth*7/35,displayHeight*49/56, displayWidth*6/35, displayHeight*2/35);
fill(reset);
//
fill(black);
textAlign(CENTER,CENTER);
size=20;
textFont(font, size);
text(songMetaData[currentSong].author(), displayWidth*8/35,displayHeight*13/14, displayWidth*4/35, displayHeight*1/35);
fill(reset);
//
fill(black);
textAlign(CENTER,CENTER);
size=20;
textFont(font, size);
text(currentTime, displayWidth*27/70,displayHeight*53/56, displayWidth*4/35, displayHeight*1/35);
fill(reset);
//
fill(black);
textAlign(CENTER,CENTER);
size=20;
textFont(font, size);
if(currentSong==0)text(time1, displayWidth*47/70,displayHeight*53/56, displayWidth*4/35, displayHeight*1/35);
//
if(currentSong==1)text(time2, displayWidth*47/70,displayHeight*53/56, displayWidth*4/35, displayHeight*1/35);
//
if(currentSong==2)text(time3, displayWidth*47/70,displayHeight*53/56, displayWidth*4/35, displayHeight*1/35);
//
if(currentSong==3)text(time4, displayWidth*47/70,displayHeight*53/56, displayWidth*4/35, displayHeight*1/35);
//
if(currentSong==4)text(time5, displayWidth*47/70,displayHeight*53/56, displayWidth*4/35, displayHeight*1/35);
//
fill(reset);
//
textAlign (LEFT, LEFT);
size = 20; //Change until fit
textFont(font, size);
text(pen, displayWidth*1/35, displayWidth*1/70, displayWidth*2/35, displayWidth*1/70);
fill(reset);
//
textAlign (LEFT, LEFT);
size = 20; //Change until fit
textFont(font, size);
text(canvas, displayWidth*1/35, displayWidth*11/70, displayWidth*2/35, displayWidth*1/70);
fill(reset);
//
textAlign (LEFT, LEFT);
size = 20; //Change until fit
textFont(font, size);
text(stroke, displayWidth*1/35, displayWidth*21/70, displayWidth*2/35, displayWidth*1/70);
fill(reset);
//
textAlign (LEFT, LEFT);
size = 20; //Change until fit
textFont(font, size);
text(shapes, displayWidth*1/35, displayWidth*107/280, displayWidth*2/35, displayWidth*1/70);
fill(reset);

}//End textDraw
//Global Variables
//
public void drawingTools() {
  strokeWeight(lineStroke);
  stroke(toolColour);
  fill(toolColour);
if(drawLine==true){ 
  if (drawTool==true && mouseX>=drawingSurfaceX && mouseX<=drawingSurfaceX+drawingSurfaceWidth && mouseY>=drawingSurfaceY && mouseY<=drawingSurfaceY+drawingSurfaceHeight)
 line( mouseX, mouseY, pmouseX, pmouseY );
 frameRate = 240;
}
//
if(drawCircle==true){
  if (drawTool==true && mouseX>=drawingSurfaceX && mouseX<=drawingSurfaceX+drawingSurfaceWidth && mouseY>=drawingSurfaceY && mouseY<=drawingSurfaceY+drawingSurfaceHeight) 
  ellipse ( mouseX, mouseY, drawingDiameter, drawingDiameter );//Circle drawing tool
  frameRate = 24;
}
//
if(drawTriangle==true){
  if (drawTool==true && mouseX>=drawingSurfaceX && mouseX<=drawingSurfaceX+drawingSurfaceWidth && mouseY>=drawingSurfaceY && mouseY<=drawingSurfaceY+drawingSurfaceHeight) 
  triangle ( mouseX, mouseY-strokeHeight*1/4, mouseX-strokeWidth*1/3, mouseY+strokeHeight*1/4, mouseX+strokeWidth*1/3, mouseY+strokeHeight*1/4 );//Triangle drawing tool
  frameRate = 24;
}
//
if(drawRectangle==true){
  if (drawTool==true && mouseX>=drawingSurfaceX && mouseX<=drawingSurfaceX+drawingSurfaceWidth && mouseY>=drawingSurfaceY && mouseY<=drawingSurfaceY+drawingSurfaceHeight) 
  rect ( mouseX-displayWidth*1/40, mouseY-displayWidth*1/80, displayWidth*1/20, displayWidth*1/40 );//Rectangle drawing tool
  frameRate = 24;
}
}//End drawingTools
  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--hide-stop", "Drawing_and_Music_Program" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
